# Part 2

## Video Demo

Please provide the YouTube link to your [Video Demo](https://youtu.be/B6FVB1fcJWs).

## Minimum Requirements

### Completed

List all the features completed.

1. Introduction-Instruction
2. Insert Rows and columns for map
3. Moving Alien based on user's commands
4. Collecting health pack(h)
5. Continue playing or Exit(Enter 1 to play again or Enter 2 to exit);

### To Do


## Additional Features

Cool word animation in introduction and loading animation

## Contributions

List down the contribution of each group members.

For example:

Flavian Navin Wenceslas

1. Insert Rows and Columns to create Map
2. Moving Alien
3. Collecting health pack points
4. If else statement to move Alien

Ahbinesh a/L Parthasarthy

1. If else statement to execute game or continue playing  
2. Word animation in introduction


Nur Sarah Sabrina binti Nazli 

1. Characters on game board
2. Loading animation 


## Problems Encountered & Solutions

Describe the problems encountered and provide the solutions / plan for the solutions.