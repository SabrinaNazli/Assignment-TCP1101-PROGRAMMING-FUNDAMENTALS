# Alien vs. Zombie

Please introduce the game here.

https://youtu.be/3DaHepffkwk

## Compilation Instructions

Provide instructions on how to compile your program, especially when it is non-trivial.

For example:

```
g++ main.cpp 
```

## User Manual

g++ main.cpp 
```

## Progress Log

- [Part 1](PART1.md)
- [Part 2](PART2.md)

## Contributors

Please replace the following with your group members' names. 

- Flavian Navin Wenceslas
- Ahbinesh a/L Parthasarthy
- Nur Sarah Sabrina binti Nazli 


