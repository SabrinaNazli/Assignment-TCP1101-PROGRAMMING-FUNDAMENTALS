# Part 1

## Video Demo

https://youtu.be/3DaHepffkwk

## Minimum Requirements

### Completed

List all the features completed.

1. Animation charater(introduction)
2. Loading animation
3. Restart game

### To Do

List all the features not yet done. Remove this section if there is no incomplete requirements.

1. Moving rover according to user input 
2. user input creating rows and columns for map
3. Alien to encounter Rock(to execute game)


## Contributions

List down the contribution of each group members.

For example:

### Flavian Navin Wenceslas

1. Intro Animationn 
2. Alien Movement

### Ahbinesh a/L Parthasarthy

1. Loading animation 
2. Restart game

### Nur Sarah Sabrina binti Nazli 

1. Create game board
2. Characters in map

## Problems Encountered & Solutions

Describe the problems encountered and provide the solutions / plan for the solutions.